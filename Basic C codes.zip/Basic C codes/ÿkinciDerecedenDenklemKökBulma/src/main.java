public class main {

	public static void main(String[] args) {
		
		function.findTheRootsOfEquation�nSecondOrder(    Integer.parseInt(args[0]),
													     																	 Integer.parseInt(args[1]),
													     																	 Integer.parseInt(args[2])          );
		
	}
}
