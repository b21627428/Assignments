public class AmericanPan implements Material {

	@Override
	public int getCost() {
		
		return 5;
	}

	@Override
	public String getName() {
		
		return "AmericanPan";
	}



}
