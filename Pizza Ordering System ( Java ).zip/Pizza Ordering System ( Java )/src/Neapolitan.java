public class Neapolitan implements Material {

	@Override
	public int getCost() {
		
		return 10;
	}

	@Override
	public String getName() {
		
		return "Neapolitan";
	}



}
