public interface Material {
	
	public int getCost();
	
	public String getName();
	


}
