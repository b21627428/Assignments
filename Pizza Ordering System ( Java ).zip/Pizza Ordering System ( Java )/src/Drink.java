public class Drink implements Material{
	
	@Override
	public int getCost() {
		
		return 1;
	}

	@Override
	public String getName() {
		
		return "Softdrink";
	}


	
	
	


	
	
}
