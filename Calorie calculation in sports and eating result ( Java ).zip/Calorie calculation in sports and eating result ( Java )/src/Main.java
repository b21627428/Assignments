

public class Main {
    
    public static void main(String[] args) {
        
        
        WriteTheFiLe.commandsCompare( args[0] ,     HumanProduction.produceMethod("people.txt") ,     FoodProduction.produceMethod("food.txt") ,       SportProduction.produceMethod("sport.txt"));
       
         /*   HumanProduction.produceMethod  people.txt içindeki özellikleri çeker, human lar  oluşturur ve bunları bir arraye atar.Ardından  human nesnelerini içeren arrayi return eder... */
         /*   FoodProduction.produceMethod  food.txt içindeki özellikleri çeker, food lar  oluşturur ve bunları bir arraye atar.Ardından  food nesnelerini içeren arrayi return eder...*/
         /*   SportProduction.produceMethod  sport.txt içindeki özellikleri çeker, sport lar  oluşturur ve bunları bir arraye atar.Ardından  sport nesnelerini içeren arrayi return eder...*/
         
         /*   WriteTheFile.commandsCompare methodu ise command.txt deki bilgileri çekip 2 boutlu bir listeye atar. Ardından bu 2 boyutlu listedeki bilgilerle yapılan kıyaslamalara göre human ların özellikleri değiştirilir.
         ve yapılan değişiklikler dosyaya yazdırılır...
         */
        
        
       
        
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
   
    
    
    
    
    
}
