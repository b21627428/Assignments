#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "structs.h"



client* createClients( char *textName  , int *numberOfClients){
	
	FILE *clients;      int  i,j;   char *temp = (char *) malloc(sizeof(char)*25);  
	
	clients = fopen(textName,"rb+");
	
	fscanf(clients,"%d", numberOfClients);
	
	client *AllClients;
	AllClients = (client *) malloc (  sizeof(client) * (*numberOfClients) ) ;
	
	for(i=0 ; i<*numberOfClients ; i++ ){
		
		for(j=0 ; j<3 ; j++){
			
			if     (j==0){
				
				fscanf( clients,"%s",temp );
				strcpy(AllClients[i].ClientID , temp);				
			}           
			
			else if(j==1){
				fscanf( clients,"%s",temp);
				strcpy(AllClients[i].ClientIPAdress , temp);
			}			 
			
			else if(j==2){

				fscanf( clients,"%s",temp);
				strcpy(AllClients[i].ClientMacAddress , temp);				
			}
		}
		AllClients[i].numberOfLogs = 0;
		AllClients[i].headOfInArray=-1;     		AllClients[i].tailOfInArray=-1;
		AllClients[i].headOfOutArray=-1;            AllClients[i].tailOfOutArray=-1;
	}
	free(temp);
	fclose(clients);
	
	return AllClients;
	
	
}
