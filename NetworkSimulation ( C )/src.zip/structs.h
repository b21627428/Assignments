

typedef struct{
	
	char *Message;
	int numberOfFrames;
	int numberOfHops;
	char senderID[5];
	char receiverID[5];
	char Activity[25];
	char Success[5];
	char Timestamp[20];

	
	
}LOGEntry;



typedef struct{
	
	char ***layer;
	
	int numberOfHop;
	
	int tailOfLayer;
	 
}frame;

typedef struct{
	
	frame *IncomingQueueOfClient;
	int headOfInArray;
	int tailOfInArray;
	
	frame *OutgoingQueueOfClient;
	int headOfOutArray;
	int tailOfOutArray;
	
	char ClientID[5];
	char ClientIPAdress[20];
	char ClientMacAddress[20];
	
	char **routingTable;
	int numberOfClientsInRoutingTable ;
	
	int numberOfLogs;
	LOGEntry *logArray;   // Her �zerinde i�lem yap�ld�k�a realloc yap�lacak ve numberOFLogs artt�r�lacak.
		
}client;
