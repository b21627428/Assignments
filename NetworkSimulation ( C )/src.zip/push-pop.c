#include <stdlib.h>
#include "structs.h"
#include <string.h>


void push(char *layer , char *information ){
	
	strcpy( layer , information);
}
char** pop( frame *temp ){
	
	return temp->layer[ temp->tailOfLayer ];
}
