#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char*** createCommands( char *textName){
	
	FILE *commandsTxt ;         commandsTxt = fopen(textName,"rb+");			 int counter = 1 , secondCounter = 0 ;
	
	char ***commands;
	char *temp = (char *) malloc(sizeof(char)*500);
	char *spliter ,*token;
	

	spliter = fgets(temp,500,commandsTxt);
	commands = (char ***) malloc(sizeof(char**) *atoi(temp)+1);
	
	while(spliter != NULL){
		
		
		commands[secondCounter] = (char**) malloc(sizeof(char*)*1);		
		
		token = strtok(temp," ");
		
		while(token!=NULL){
				
				
				counter++;
				
				commands[secondCounter] = ( char **) realloc( commands[secondCounter] , sizeof(char*) * (counter) ) ;
				commands[secondCounter][counter-1 ] = (char*) malloc(sizeof(char)*strlen(token)+1);
				strcpy( commands[secondCounter][counter-1] , token);
				
	
				token = strtok(NULL," ");
		}
		
		commands[secondCounter][0] = (char *) malloc(sizeof(char)*100);
		sprintf(commands[secondCounter][0] , "%d", counter-1);

		counter=1;
		secondCounter++;	
		
		
		
		spliter = fgets(temp,500,commandsTxt);
		
	}

    fclose(commandsTxt);
    free(temp);
    free(spliter);
    
	return commands;
    
}
