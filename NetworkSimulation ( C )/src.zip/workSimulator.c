#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "functions.h"

int findTheClient( client *AllClients , int numberOfClients , char *searchingClient);
void printMessageCommand(char ***commands , int index );
void printMessage(char *message);
void printShowFrameInfo(frame *temp ,int index , char *OutOrIn);


void workSimulator ( char *senderPort ,char *receiverPort , int sizeDivision ,         char ***commands , client *AllClients ,          int numberOfClients ){
	

	client **RoutingClientsArray = (client **) malloc(sizeof(client*)* (numberOfClients));      // Rotay� belirlemek i�in kullan�lan array  , E�er A dan E ye gidecekse   BDE arrayi olu�ur.

	char *p ,*stripTemp, *message;                     // Mesaj realloc yap�l�p olu�turulur.     char *p , *stripTemp;
	
	int LenOfRoutingClientsArray , LenOfMessage ;                 
	
	int i ,counter ,k;

	
	for (i = 1; i <= atoi(commands[0][1]) ; i++ ){
	
		
		if( strcmp(commands[i][1] ,"MESSAGE") == 0 && atoi(commands[i][0])>3 ){
			
			int z = findTheClient(AllClients , numberOfClients, commands[i][3] );  k=z;
					
			LenOfRoutingClientsArray = 0;    LenOfMessage = 0;
			
			printMessageCommand(commands , i );
			createRightRoute( AllClients , commands[i][2][0] , commands[i][3][0] , RoutingClientsArray , &LenOfRoutingClientsArray , numberOfClients );  //Do�ru rotay� array'e at�yor . ( BDE gibi)
			message = Message(  i , commands  , &LenOfMessage );
			printMessage(message);
			
			RoutingClientsArray[0]->tailOfOutArray = -1 ;  RoutingClientsArray[0]->headOfOutArray = -1;
			
			if (LenOfRoutingClientsArray >=2 )createMainClientQueue( RoutingClientsArray[0], &AllClients[z], RoutingClientsArray[1], LenOfMessage , sizeDivision,  message , senderPort ,receiverPort);
			else  printf("Error: Unreachable destination.");


			
		}
		else if ( strcmp(commands[i][1] ,"SHOW_FRAME_INFO") == 0 && atoi(commands[i][0])==4){
			
			int z = findTheClient(AllClients , numberOfClients , commands[i][2]);
			
			printMessageCommand(commands , i);
			
			if (  z != -1 ){
				
				if( strcmp (commands[i][3] , "in") == 0){
				
					if ( atoi(commands[i][4]) > AllClients[z].tailOfInArray   ){
					
						printf("No such frame.\n");
					}				
					else{

						printShowFrameInfo( &AllClients[z].IncomingQueueOfClient[ atoi(commands [i][4])-1], atoi(commands[i][4]) , "incoming");
					}
				}
				else{
				
					if ( atoi(commands[i][4]) > AllClients[z].tailOfOutArray ){
						
						printf("No such frame.\n");
					}
					else{
						
	
						printShowFrameInfo( &AllClients[z].OutgoingQueueOfClient[ atoi(commands [i][4])-1], atoi(commands[i][4]) , "outgoing");
						
					}
				}				
			}
			else{
				
				printf("No such client %s\n",commands[i][2]);
				
				
			}

		}
		
		else if ( strcmp(commands[i][1] ,"SHOW_Q_INFO") == 0 && atoi(commands[i][0])==3){
			
			int z = findTheClient(AllClients , numberOfClients , commands[i][2]);
			
			commands[i][3][strlen(commands[i][3])-1] = '\0';
			
			printMessageCommand(commands , i);			
			if (  z != -1 ){
				
				if( strcmp(commands[i][3] ,"out" ) == 0){
				
					printf("Client %s Outgoing Queue Status\nCurrent total number of frames out: %d\n",AllClients[z].ClientID   ,AllClients[z].tailOfOutArray-AllClients[z].headOfOutArray);

				}
				else{
						
					printf("Client %s Incoming Queue Status\nCurrent total number of frames in: %d\n",AllClients[z].ClientID  , AllClients[z].tailOfInArray-AllClients[z].headOfInArray);
					
				}				
			}
			else{
				
				printf("No such client %s",commands[i][2]);
				
				
			}

		}
		else if ( strcmp(commands[i][1], "SEND" ) == 0 && atoi(commands[i][0])==2){
			
			printMessageCommand(commands , i);
			
			if ( LenOfRoutingClientsArray >= 2 ) send( RoutingClientsArray[0] , RoutingClientsArray[1] , &AllClients[k] , RoutingClientsArray , 2 , LenOfRoutingClientsArray ,message);
			else  printf("Error: Unreachable destination. Packets are dropped after 0 hops!");//FA�L DURUMU
			
			
		}
		else if ( strcmp(commands[i][1], "PRINT_LOG" ) == 0 && atoi(commands[i][0])==2){
			
			printMessageCommand(commands , i);
			
			int z = findTheClient(AllClients , numberOfClients , commands[i][2]  ) , counter ;
			
			printf("Client %s Logs:\n",commands[i][2]);
			
			for(counter=0 ; counter < AllClients[z].numberOfLogs ; counter++){
				
				printf("--------------\n");
				
				printf("Log Entry #%d:\n",counter+1);
				printf("Timestamp: %s\n",AllClients[z].logArray[counter].Timestamp);
				printf("Message: %s\n",AllClients[z].logArray[counter].Message);
				printf("Number of Frames: %d\n",AllClients[z].logArray[counter].numberOfFrames);
				printf("Number of hops: %d\n",AllClients[z].logArray[counter].numberOfHops);
				printf("Sender ID: %s\n",AllClients[z].logArray[counter].senderID);
				printf("Receiver ID: %s\n",AllClients[z].logArray[counter].receiverID);
				printf("Activity: %s\n",AllClients[z].logArray[counter].Activity);
				printf("Success: %s\n",AllClients[z].logArray[counter].Success);
				
			}
			if(AllClients[z].numberOfLogs==0)  printf("There is no Log Entry.\n");
			
			
		}
		else{
			
			printMessageCommand(commands , i);
			printf("Invalid command\n");
		}
		
		
	}

	


}















int findTheClient( client *AllClients , int numberOfClients , char *searchingClient){
	
	int counter ;
	
	for(counter = 0 ; counter<numberOfClients ; counter++){
	
		if( strcmp( AllClients[counter].ClientID , searchingClient ) == 0 ){
			
			return counter;
			
		}
	
	
	}
	
	return -1;
}









void printMessageCommand(char ***commands , int index ){
	
	int counter , len = 9 ;
	
	for( counter = 1 ; counter <atoi( commands[index][0] ) ; counter++ ){
		
		len += (strlen(commands[index][counter])+1);
	}
	len += strlen(commands[index][counter]);
	
	for(counter=0 ; counter <=len ; counter++){
		
		printf("-");
	}
	printf("\nCommand: ");

	for( counter = 1 ; counter <atoi( commands[index][0] ) ; counter++ ){
		
		printf("%s ",commands[index][counter]);
	}
	if( commands[index][counter] [ strlen( commands[index][counter]) -1 ] == '\n' )  commands[index][counter][ strlen(commands[index][counter]) -1 ] = '\0';

	printf("%s\n",commands[index][counter]);
	

	for(counter=0 ; counter <=len ; counter++){
			
		printf("-");
	}	
	printf("\n");
	
}








void printMessage(char *message){
	
	
	printf("Message to be sent: %s\n\n",message);
	
}









void printShowFrameInfo(frame *temp ,int index , char *OutOrIn){
	
	
	printf("Current Frame #%d on the %s queue of client C\n",index , OutOrIn );
	int counter;
	for( counter=0 ; counter <=  temp->tailOfLayer ; counter++ ){
		if      (counter == 0){
				                    printf("Carried Message: \"%s\"\nLayer 0 info: Sender ID: %s, Receiver ID: %s\n",temp->layer[counter][0], temp->layer[counter][1], temp->layer[counter][2]);
																													 
		} 																	
		else if (counter == 1){
									printf("Layer 1 info: Sender port number: %s, Receiver port number: %s\n",temp->layer[counter][0],temp->layer[counter][1]);
		} 																			
		else if (counter == 2){
									printf("Layer 2 info: Sender IP address: %s, Receiver IP address: %s\n",temp->layer[counter][0],temp->layer[counter][1]);	
		} 
		else if (counter == 3){
									printf("Layer 3 info: Sender MAC address: %s, Receiver MAC address: %s\n",temp->layer[counter][0],temp->layer[counter][1]);
		} 
	}
	printf("Number of hops so far: %d\n",temp->numberOfHop);	
}






