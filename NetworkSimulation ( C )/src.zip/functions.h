#include "structs.h"

//main
	client* createClients( char *textName  , int *numberOfClients);
	
	void createRoutingTables ( char *textName  , int *numberOfClients , client *AllClients);
	
	char*** createCommands( char *textName);
	
	void workSimulator ( char *senderPort ,char *receiverPort , int sizeDivision ,         char ***commands , client *AllClients ,          int numberOfClients );
		
		void createMainClientQueue ( client *mainClient , client *destinationClient ,  client *nextClient , int LenOfMessage , int sizeDivision , char *message , char *senderPort , char *receiverPort);
	


		void send( client *backClient , client *nextClient , client *destinationClient , client **routingClientsArray , int index ,int LenOfRoutingClientsArray , char *message );
		
		
//Yard�mc� Fonksiyonlar		
void createRightRoute( client *AllClients , char mainClient , char destinationClient ,client **array,  int *LenOfArray , int numberOfClients);
char* Message( int i , char ***commands ,int *LenOfMessage );

void push(char *layer , char *information );
char** pop( frame *temp );
void Enqueue(frame *queue , int index , frame *temp);
frame* Dequeue(frame *queue , int headOfArray );
