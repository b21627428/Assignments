#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "functions.h"


int main(int argc,char** argv){

	int numberOfClients  ;     	client *AllClients;      	char ***Commands ; 

	
	AllClients = createClients(argv[1], &numberOfClients);
					 
	createRoutingTables(argv[2], &numberOfClients, AllClients );
	
	Commands   = createCommands(argv[3]);
	
	
	workSimulator(argv[5], argv[6], atoi(argv[4]), Commands, AllClients, numberOfClients);

	
	return 0;
}






