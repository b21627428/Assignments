#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "structs.h"


void stripTheMessage( char *s , int number ,int sizeOf  ){
	
	int i;
	
	if(number == 4){

		for(i=1 ; i< strlen(s); i++){

			s[i-1] = s[i];
		}
		s[i-1] = '\0';

		
	}
	else{
		
		s[sizeOf] = '\0';
	
	}

}


char * createMessage(int i,char ***commands ,int *lenOfMessage){
	
	int j ,k ;    char *p ,*stripTemp ;
	
	char *message = (char *) malloc(sizeof(char)*2);
	strcpy(message,"-");
	
	//MESAJI B�R ARRAYDE TOPLAMA KISMI
	for(j = 4 ; j <= atoi( commands[i][0]) ; j++ ){


		
		if( j == atoi(commands[i][0]) ){
					
			message = (char *) realloc ( message , sizeof(char)* (strlen(message)+strlen(commands[i][j]) )+1 );
					
			stripTheMessage( commands[i][j] , j , strlen(commands[i][j])-1 );					
					
			for( p=message , k=0 ; k< strlen(message) ; k++ , p++);	
					
			strcpy( p , commands[i][j] )	;		
			(*lenOfMessage) = strlen(message)+1; // NULL DAH�L 
					
			return  message;        
					
 		}
		else if( j == 4){
				
			message = (char *) realloc ( message , sizeof(char)* (strlen(message)+strlen(commands[i][j]) )+1 );	
				
			stripTheMessage( commands[i][j] , 4, strlen(commands[i][j]) );
					
			p=message;	
			
			strcpy(p ,strcat( commands[i][j] ," ") );
		
							
					
		}
		else{
					
			message = (char *) realloc ( message , sizeof(char)* (strlen(message)+1+strlen(commands[i][j])+1 ) );
					
			for( p=message , k=0 ; k< strlen(message) ; k++ , p++);	
					
			strcpy( p , strcat( commands[i][j] ," ") )	;
			
		}			
	}
	free(p);
	free(stripTemp);
	return NULL;
	
}	




char* Message(  int i , char ***commands ,int *LenOfMessage ){
	
		char * message ;
					
		message = createMessage(i,commands, LenOfMessage);	
		
		return message;
	
	
}
