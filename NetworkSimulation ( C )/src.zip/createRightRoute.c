#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "structs.h"

void createRightRoute( client *AllClients , char mainClient , char destinationClient ,  client **array, int *LenOfArray , int numberOfClients){     // A dan E ye ba�lant� varsa A-B-E arrayini d�ncek di�er t�rl� NULL d�ncek.
	
	int i,j ,k;  char *temp = (char *) malloc(sizeof(char)*2);
	
	array[*LenOfArray] =(client*) malloc(sizeof(client)*1);

	
	for( i=0 ; i<numberOfClients ; i++){
		
		if( AllClients[i].ClientID[0] == mainClient ){
			
				if(*LenOfArray==0){
					array[*LenOfArray] = &AllClients[i];
					(*LenOfArray)++;

				}

			for( j=0 ; j< AllClients[i].numberOfClientsInRoutingTable ; j++){
				
				if( destinationClient == AllClients[i].routingTable[j][0] ){
			
					
					for(k=0 ; k<numberOfClients ; k++){
						
						if ( destinationClient != AllClients[i].routingTable[j][1] && AllClients[k].ClientID[0] == AllClients[i].routingTable[j][1] ){
							
								
								array[*LenOfArray] =  &AllClients[k] ;
								(*LenOfArray)++;
	
								createRightRoute(       AllClients ,   AllClients[i].routingTable[j][1]  ,    destinationClient  ,array, LenOfArray ,numberOfClients);
									
							  
							
						}
						else if(destinationClient == AllClients[i].routingTable[j][1]  && AllClients[k].ClientID[0] == AllClients[i].routingTable[j][1] ){
							
							array[*LenOfArray] =  &AllClients[k];
							
							(*LenOfArray)++;
							
							return;
						}
						else if(destinationClient == AllClients[i].routingTable[j][1]  && '-' == AllClients[i].routingTable[j][1] ){       // De�i�en K�s�m
							
							return;
						}
					}
				
				}	
			}
		}
	}
	

}
