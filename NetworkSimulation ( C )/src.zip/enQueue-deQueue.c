#include "structs.h"
#include <stdlib.h>

void Enqueue(frame *queue , int tailOfArray , frame *temp){
	
	queue[tailOfArray] = *temp;
}
frame* Dequeue(frame *queue , int headOfArray ){
	
	return &queue[headOfArray];
}



