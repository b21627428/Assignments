#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "structs.h"


void createRoutingTables ( char *textName  , int *numberOfClients , client *AllClients){
	
	FILE *textOfRoutingTables;                                int counter = 0 , secondCounter = 0 , clientCounter = 0;
	
	textOfRoutingTables = fopen(textName ,"rb+");
	
	char *temp = (char *) malloc(sizeof(char)*10);
	char *spliter ,*token;
	
	AllClients[clientCounter].routingTable = (char **) malloc(sizeof(char*)*1);
	AllClients[clientCounter].routingTable[0] = (char *) malloc(sizeof(char) *3);
	
	do {

		spliter = fgets(temp,10,textOfRoutingTables); /* bir satir okuyalim */
     
		if (spliter != NULL)
        	
        	if( temp[0] == '-'){
        	
				AllClients[clientCounter].numberOfClientsInRoutingTable = counter;
				counter=0;
				clientCounter++;
				AllClients[clientCounter].routingTable = (char **) malloc(sizeof(char*)*1);
				AllClients[clientCounter].routingTable[0] = (char *) malloc(sizeof(char) *3);
				
			}else{
 				

 				
			    token = strtok(temp, " "); 
			    AllClients[clientCounter].routingTable[counter][secondCounter] = token[0] ;
				secondCounter++;
				
				
				token = strtok(NULL, " ");
 				AllClients[clientCounter].routingTable[counter][secondCounter] = token[0] ;	
				counter++;
				secondCounter=0; 

				AllClients[clientCounter].routingTable = ( char **) realloc( AllClients[clientCounter].routingTable , sizeof(char*) * (counter+1) ) ;
				AllClients[clientCounter].routingTable[counter] = (char *) malloc(sizeof(char)*3);
				
				
			}
			   
   
   } while (spliter != NULL);          /* ta ki NULL olana kadar.. */
   
  	AllClients[clientCounter].numberOfClientsInRoutingTable = counter;

	fclose(textOfRoutingTables);
	
}
