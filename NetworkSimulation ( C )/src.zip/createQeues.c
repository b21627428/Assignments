#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "functions.h"
#include <time.h>

//void printOutFrame( frame *printingFrame  , int tailOfOutArray);

void ApplicationLayer(  client *mainClient , client *destinationClient , frame *temp, char *message , int counter , int secondCounter ,int LenOfMessage ,int sizeDivision  ){
	
	int i; char *tempArray;
	
	if( secondCounter < LenOfMessage){
		
		tempArray = (char*) malloc(sizeof(char)*(secondCounter-counter)+1);
		
		for(i=counter ; i<secondCounter ; i++ ){
			
			tempArray[i%sizeDivision] = message[i];
		}

		tempArray[sizeDivision] = '\0';
	
	}
	else{
		
		tempArray = (char*) malloc(sizeof(char)*(LenOfMessage-counter));
		
		for(i=counter ; i<LenOfMessage ; i++){
			
			tempArray[i%sizeDivision] = message[i];
		}
		
		tempArray[sizeDivision] = '\0';

	}
	
	(*temp).layer[0][0] = (char*) malloc(sizeof(char)*strlen( 	tempArray  )+1);
	push( (*temp).layer[0][0] , tempArray );
		

	(*temp).layer[0][1] = (char*) malloc(sizeof(char)*strlen( (*mainClient).ClientID   )+1);
	push ( (*temp).layer[0][1] , (*mainClient).ClientID );
	
	
	(*temp).layer[0][2] = (char*) malloc(sizeof(char)*strlen( (*destinationClient).ClientID)+1);
	push ( (*temp).layer[0][2] , (*destinationClient).ClientID );
	
	free(tempArray);	
	

}
void TransportLayer( frame *temp , char *senderPort , char *receiverPort){
	
	(*temp).layer[1][0] = (char*) malloc(sizeof(char)*strlen( senderPort   )+1);
	push ( (*temp).layer[1][0]  , senderPort );
	
	(*temp).layer[1][1] = (char*) malloc(sizeof(char)*strlen( receiverPort  )+1);
	push ( (*temp).layer[1][1] , receiverPort );	
	 
}
void NetworkLayer( client *mainClient ,client *destinationClient ,frame *temp ){
	
	(*temp).layer[2][0] = (char*) malloc(sizeof(char)*strlen( (*mainClient).ClientIPAdress  )+1);
	push ( (*temp).layer[2][0] , (*mainClient).ClientIPAdress );
	
	(*temp).layer[2][1] = (char*) malloc(sizeof(char)*strlen( (*destinationClient).ClientIPAdress   )+1);
	push ( (*temp).layer[2][1] , (*destinationClient).ClientIPAdress);
	
}
void PhysicalLayer( client *mainClient , client *nextClient ,frame *temp ){
	
	(*temp).layer[3][0] = (char*) malloc(sizeof(char)*strlen( (*mainClient).ClientMacAddress  )+1);
	push ( (*temp).layer[3][0] , (*mainClient).ClientMacAddress );
	
	(*temp).layer[3][1] = (char*) malloc(sizeof(char)*strlen( (*nextClient).ClientMacAddress   )+1);
	push ( (*temp).layer[3][1] , (*nextClient).ClientMacAddress);
	
	
}








void createMainClientQueue ( client *mainClient , client *destinationClient ,  client *nextClient , int LenOfMessage , int sizeDivision , char *message , char *senderPort , char *receiverPort){
	
	
	int counter , secondCounter , numberOfLoop , thirdCounter;


	if( LenOfMessage % sizeDivision == 0) numberOfLoop = LenOfMessage / sizeDivision;
	else   numberOfLoop = (LenOfMessage / sizeDivision)+1;
	
	
	
		
		mainClient->OutgoingQueueOfClient = (frame*) malloc (sizeof(frame)* numberOfLoop);
		
		
		for(counter=0 ; counter<numberOfLoop ; counter++){
			
			frame temp;
			
			temp.layer = (char***) malloc(sizeof(char**) *4);
			temp.tailOfLayer = -1; temp.numberOfHop=0;


			for(secondCounter=0 ; secondCounter<4 ; secondCounter++){
				
				if(secondCounter == 0) temp.layer[ ++temp.tailOfLayer ] = (char**) malloc(sizeof(char*)*3);
				else                   temp.layer[ ++temp.tailOfLayer ] = (char**) malloc(sizeof(char*)*2);

				
			}
			               

			ApplicationLayer( mainClient , destinationClient ,&temp , message, counter*sizeDivision , (counter*sizeDivision)+sizeDivision , LenOfMessage ,sizeDivision );
			TransportLayer( &temp , senderPort ,receiverPort);
			NetworkLayer( mainClient ,destinationClient ,&temp );
			PhysicalLayer( mainClient ,nextClient ,&temp );
			
			
			
			Enqueue( (*mainClient).OutgoingQueueOfClient ,++mainClient->tailOfOutArray , &temp );
			
			
			printf("Frame #%d\n", mainClient->tailOfOutArray+1);
			for(thirdCounter = mainClient->OutgoingQueueOfClient[ mainClient->tailOfOutArray].tailOfLayer ; thirdCounter>=0 ; thirdCounter--){
				
				if(thirdCounter == 3){
				
					printf("Sender MAC address: %s, Receiver MAC address: %s\n", mainClient->OutgoingQueueOfClient[ mainClient->tailOfOutArray].layer[thirdCounter][0] ,  mainClient->OutgoingQueueOfClient[ mainClient->tailOfOutArray].layer[thirdCounter][1]);	
					
				}
				else if( thirdCounter == 2){
					
					printf("Sender IP address: %s, Receiver IP address: %s\n", mainClient->OutgoingQueueOfClient[ mainClient->tailOfOutArray].layer[thirdCounter][0] ,  mainClient->OutgoingQueueOfClient[ mainClient->tailOfOutArray].layer[thirdCounter][1]);
					
				}
				else if( thirdCounter == 1){
					
					printf("Sender port number: %s, Receiver port number: %s\n", mainClient->OutgoingQueueOfClient[ mainClient->tailOfOutArray].layer[thirdCounter][0],  mainClient->OutgoingQueueOfClient[ mainClient->tailOfOutArray].layer[thirdCounter][1]);
				}
				else{
					
					printf("Sender ID: %s, Receiver ID: %s\nMessage chunk carried: %s\n--------\n", mainClient->OutgoingQueueOfClient[ mainClient->tailOfOutArray].layer[thirdCounter][1], mainClient->OutgoingQueueOfClient[ mainClient->tailOfOutArray].layer[thirdCounter][2], mainClient->OutgoingQueueOfClient[ mainClient->tailOfOutArray].layer[thirdCounter][0]);
					
				}
				
				
			}
			
		}
		


	
	
		mainClient->logArray = (LOGEntry*) malloc(sizeof(LOGEntry)*1);

		time_t now = time(NULL);
		strftime(mainClient->logArray [ mainClient->numberOfLogs ].Timestamp, 20, "%Y-%m-%d %H:%M:%S", localtime(&now));
	
		mainClient->logArray [ mainClient->numberOfLogs ].Message = (char *) malloc(sizeof(char)*strlen(message)+1);
		strcpy( mainClient->logArray [ mainClient->numberOfLogs ].Message , message );
		
		mainClient->logArray [ mainClient->numberOfLogs ].numberOfFrames = mainClient->tailOfOutArray - mainClient->headOfOutArray;
		mainClient->logArray [ mainClient->numberOfLogs ].numberOfHops   = mainClient->OutgoingQueueOfClient [ mainClient->headOfOutArray+1].numberOfHop;	
		strcpy( mainClient->logArray [ mainClient->numberOfLogs ].senderID   , mainClient->OutgoingQueueOfClient [ mainClient->headOfOutArray+1].layer[0][1]) ;
		strcpy( mainClient->logArray [ mainClient->numberOfLogs ].receiverID   , mainClient->OutgoingQueueOfClient [ mainClient->headOfOutArray+1].layer[0][2]) ;
		strcpy( mainClient->logArray [ mainClient->numberOfLogs ].Activity , "Message Forwarded");
		strcpy( mainClient->logArray [ mainClient->numberOfLogs ].Success , "Yes");
		
		mainClient->numberOfLogs++;
		
	

}















	

	

	

	







