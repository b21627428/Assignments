#include "functions.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>

void helper_Send_Out_To_In(client *backClient , client *nextClient ,client **RoutingClientsArray , int index );
void helper_Send_In_To_Out(client *sameClient ,client **RoutingClientsArray , int index );
void copy_Frame (frame *first , frame *second , client **RoutingClientsArray , int index, int number);
void Add_Log_Out_To_In_Success(client *temp , client *backClient , char *message );
void Add_Log_In_To_Out_Success(client *temp , char *message);
void Add_Log_Fail(client *temp , char *message);

void send( client *backClient , client *nextClient , client *destinationClient , client **RoutingClientsArray , int index , int numberOfRoutingClientsArray  , char *message){
	

	if( strcmp( destinationClient->ClientID , nextClient->ClientID ) == 0 ){    // BA�ARILI Bir �EK�LDE G�NDERMEK i�in

		nextClient->IncomingQueueOfClient = (frame*) malloc(sizeof(frame)* (backClient->tailOfOutArray-backClient->headOfOutArray) ) ;
		Add_Log_Out_To_In_Success(nextClient, backClient , message);
		helper_Send_Out_To_In(backClient , nextClient,RoutingClientsArray , index );
		free(backClient->OutgoingQueueOfClient);
		
		printf("A message received by client %s from client %s after a total of %d hops.\n",destinationClient->ClientID , RoutingClientsArray[0]->ClientID , nextClient->IncomingQueueOfClient [ nextClient->tailOfInArray ].numberOfHop );
		printf("Message: %s\n", message);
	
	}
	
	else if( numberOfRoutingClientsArray == index){     // FA�L DURUmu i�in
		
		nextClient->IncomingQueueOfClient = (frame*) malloc(sizeof(frame)* (backClient->tailOfOutArray-backClient->headOfOutArray) ) ;
		Add_Log_Out_To_In_Success(nextClient, backClient , message);
		helper_Send_Out_To_In(backClient , nextClient,RoutingClientsArray , index );
		Add_Log_Fail(nextClient,message);
		free(backClient->OutgoingQueueOfClient);
		
		printf("A message received by client %s, but intended for client %s.Forwarding...\n",nextClient->ClientID , destinationClient->ClientID);
		printf("Error: Unreachable destination.Packets are dropped after %d hops!\n",nextClient->IncomingQueueOfClient [ nextClient->tailOfInArray].numberOfHop);			
		
	}
	
	else{     //AKTARIM i�in
		
		printf("A message received by client %s, but intended for client %s.Forwarding...\n",nextClient->ClientID , destinationClient->ClientID);	

		
		nextClient->IncomingQueueOfClient = (frame*) malloc(sizeof(frame)* (backClient->tailOfOutArray-backClient->headOfOutArray) ) ;
		Add_Log_Out_To_In_Success(nextClient, backClient , message);
		helper_Send_Out_To_In(backClient , nextClient,RoutingClientsArray , index );
		free(backClient->OutgoingQueueOfClient);		

		nextClient->OutgoingQueueOfClient = (frame*) malloc(sizeof(frame)* (nextClient->tailOfInArray-nextClient->headOfInArray) );
		Add_Log_In_To_Out_Success(nextClient,message);
		helper_Send_In_To_Out(nextClient, RoutingClientsArray , index );
		free(nextClient->IncomingQueueOfClient);
		
		client *temp = RoutingClientsArray[index];
		send( nextClient , temp , destinationClient , RoutingClientsArray , ++index , numberOfRoutingClientsArray ,message);
		
		
		
	}	
	
	
	


	
	
}

void helper_Send_Out_To_In(client *backClient , client *nextClient ,client **RoutingClientsArray , int index ){
	

	if( backClient->headOfOutArray == backClient->tailOfOutArray ){

		return ;
		
	}else{

		nextClient->IncomingQueueOfClient [ ++nextClient->tailOfInArray].tailOfLayer = -1;
		
		copy_Frame(Dequeue( (*backClient).OutgoingQueueOfClient , ++backClient->headOfOutArray ) , &nextClient->IncomingQueueOfClient [ nextClient->tailOfInArray] ,RoutingClientsArray , index , 0);
		
		nextClient->IncomingQueueOfClient [ nextClient->tailOfInArray].numberOfHop++;

		helper_Send_Out_To_In(backClient , nextClient ,  RoutingClientsArray ,index );
			
	}
}


void helper_Send_In_To_Out(client *sameClient ,client **RoutingClientsArray , int index ){
	
	if(sameClient->headOfInArray == sameClient->tailOfInArray){
		
		return;
		
	}else{

		sameClient->OutgoingQueueOfClient [ ++sameClient->tailOfOutArray].tailOfLayer = -1;

		printf("\tFrame #%d",sameClient->tailOfOutArray+1);
				
		copy_Frame(Dequeue( (*sameClient).IncomingQueueOfClient , ++sameClient->headOfInArray ) , &sameClient->OutgoingQueueOfClient [ sameClient->tailOfOutArray] ,RoutingClientsArray , index , 1);		
		
		helper_Send_In_To_Out(sameClient, RoutingClientsArray ,index );
	}
}

void copy_Frame (frame *first , frame *second ,  client **RoutingClientsArray , int index ,int number){
	
	int i = 3;
	
	second->layer = (char***) malloc(sizeof(char**) * ( first->tailOfLayer)+1);
	
	while(first->tailOfLayer!=-1){

		if(first->tailOfLayer == 0){
			
			second->layer[i] = (char**) malloc(sizeof(char*)*3);		
			
			second->layer[i][0] =(char*)malloc(sizeof(char) * ( strlen(first->layer[first->tailOfLayer][0])+1 ));
			strcpy(second->layer[i][0] , first->layer[ first->tailOfLayer ][0]);
			free(first->layer[ first->tailOfLayer][0]);
			
			
			second->layer[i][1] =(char*)malloc(sizeof(char) * ( strlen(first->layer[ first->tailOfLayer][1])+1 ));
			strcpy(second->layer[i][1] , first->layer[ first->tailOfLayer ][1]);
			free(first->layer[ first->tailOfLayer][1]);
			
			second->layer[i][2] =(char*)malloc(sizeof(char) * ( strlen(first->layer[ first->tailOfLayer][2])+1 ));
			strcpy(second->layer[i][2] , first->layer[ first->tailOfLayer ][2]);
			free(first->layer[ first->tailOfLayer][2]);
					
		}
		else if(first->tailOfLayer == 3 && number == 1){
			
			second->layer[i] = (char**) malloc(sizeof(char*)*2);
			
			second->layer[i][0] =(char*)malloc(sizeof(char)* ( strlen(RoutingClientsArray[index-1]->ClientMacAddress)+1 ));
			strcpy(second->layer[i][0] , RoutingClientsArray[index-1]->ClientMacAddress);
			free(first->layer[ first->tailOfLayer ][0]);
			
			second->layer[i][1] =(char*)malloc(sizeof(char)* ( strlen(RoutingClientsArray[index]->ClientMacAddress)+1 ));
			strcpy(second->layer[i][1] , RoutingClientsArray[index]->ClientMacAddress);
			free(first->layer[ first->tailOfLayer][1]);	

			printf(" MAC address change: New sender MAC %s, New receiver MAC %s\n",second->layer[i][0] , second->layer[i][1] );		
		}
		else{
			
			second->layer[i] = (char**) malloc(sizeof(char*)*2);
			
			second->layer[i][0] =(char*)malloc(sizeof(char)* ( strlen(first->layer[ first->tailOfLayer][0])+1 ));
			strcpy(second->layer[i][0] , first->layer[ first->tailOfLayer][0]);
			free(first->layer[ first->tailOfLayer][0]);
			
			second->layer[i][1] =(char*)malloc(sizeof(char)* ( strlen(first->layer[ first->tailOfLayer][1])+1 ));
			strcpy(second->layer[i][1] , first->layer[ first->tailOfLayer][1]);
			free(first->layer[ first->tailOfLayer][1]);			

		}

		i--;
		
		first->tailOfLayer--;
	}
	
	second->tailOfLayer = 3;
	
	free(first->layer);
	
	second->numberOfHop = first->numberOfHop;
}







void Add_Log_Out_To_In_Success(client *temp, client *backClient , char *message ){
	

	temp->logArray = (LOGEntry*) malloc(sizeof(LOGEntry)*2);


	time_t now = time(NULL);
	strftime(temp->logArray [ temp->numberOfLogs ].Timestamp, 20, "%Y-%m-%d %H:%M:%S", localtime(&now));	
	
	temp->logArray [ temp->numberOfLogs ].Message = (char *) malloc(sizeof(char)*strlen(message)+1);
	strcpy( temp->logArray [ temp->numberOfLogs ].Message , message );
	
	temp->logArray [ temp->numberOfLogs ].numberOfFrames = backClient->tailOfOutArray-backClient->headOfOutArray;
	temp->logArray [ temp->numberOfLogs ].numberOfHops   = backClient->OutgoingQueueOfClient [ backClient->headOfOutArray+1].numberOfHop+1;
	strcpy( temp->logArray [ temp->numberOfLogs ].senderID   , backClient->OutgoingQueueOfClient [ backClient->headOfOutArray+1].layer[0][1]) ;
	strcpy( temp->logArray [ temp->numberOfLogs ].receiverID   ,backClient->OutgoingQueueOfClient [ backClient->headOfOutArray+1].layer[0][2]) ;
	strcpy( temp->logArray [ temp->numberOfLogs ].Activity , "Message Received");
	strcpy( temp->logArray [ temp->numberOfLogs ].Success , "Yes");
	
	temp->numberOfLogs++;
	

}




void Add_Log_In_To_Out_Success(client *temp , char *message){
	
	time_t now = time(NULL);
	strftime(temp->logArray [ temp->numberOfLogs ].Timestamp, 20, "%Y-%m-%d %H:%M:%S", localtime(&now));

	temp->logArray [ temp->numberOfLogs ].Message = (char *) malloc(sizeof(char)*strlen(message)+1);
	strcpy( temp->logArray [ temp->numberOfLogs ].Message , message );
	
	temp->logArray [ temp->numberOfLogs ].numberOfFrames = temp->tailOfInArray - temp->headOfInArray;
	temp->logArray [ temp->numberOfLogs ].numberOfHops   = temp->IncomingQueueOfClient [ temp->headOfInArray+1].numberOfHop;	
	strcpy( temp->logArray [ temp->numberOfLogs ].senderID   , temp->IncomingQueueOfClient [ temp->headOfInArray+1].layer[0][1]) ;
	strcpy( temp->logArray [ temp->numberOfLogs ].receiverID   , temp->IncomingQueueOfClient [ temp->headOfInArray+1].layer[0][2]) ;
	strcpy( temp->logArray [ temp->numberOfLogs ].Activity , "Message Forwarded");
	strcpy( temp->logArray [ temp->numberOfLogs ].Success , "Yes");
	
	temp->numberOfLogs++;	
}



void Add_Log_Fail(client *temp , char *message){

	time_t now = time(NULL);
	strftime(temp->logArray [ temp->numberOfLogs ].Timestamp, 20, "%Y-%m-%d %H:%M:%S", localtime(&now));
	
	temp->logArray [ temp->numberOfLogs ].Message = (char *) malloc(sizeof(char)*strlen(message)+1);
	strcpy( temp->logArray [ temp->numberOfLogs ].Message , message );
	
	temp->logArray [ temp->numberOfLogs ].numberOfFrames = temp->tailOfInArray-temp->headOfInArray;
	temp->logArray [ temp->numberOfLogs ].numberOfHops   = temp->IncomingQueueOfClient[ temp->headOfInArray+1].numberOfHop;	
	strcpy( temp->logArray [ temp->numberOfLogs ].senderID   , temp->IncomingQueueOfClient[ temp->headOfInArray+1 ].layer[0][1]) ;
	strcpy( temp->logArray [ temp->numberOfLogs ].receiverID   , temp->IncomingQueueOfClient[ temp->headOfInArray+1 ].layer[0][2]) ;
	strcpy( temp->logArray [ temp->numberOfLogs ].Activity , "Message Forwarded");
	strcpy( temp->logArray [ temp->numberOfLogs ].Success , "No");
	
	temp->numberOfLogs++;		
	
}


