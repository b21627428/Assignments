
public class main {

	public static void main(String[] args) {
		
		StudentPointProgram.Works(args[0]);
	}

}
