#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <iostream>    // cout cin i�in
using namespace std;
#include "Class.h"

#include <fstream>  // Dosya a�mak i�in
#include <stdlib.h>  // atoi i�in
#include <cstring>   // strtok i�in
#include <string>   // strcmp i�in





//Global pointers for footballers
footballer *footballer_head = NULL;
team *team_head = NULL;





//Prototype of Functions
footballer* addFootballer(string name , string tname );
void find_Footballer_and_add_Match(string fname  , string tname , string away_team , int minute_of_goal , int match_id);
void createLinkedList(char *textName);



void worksOperands(char *textName , char *outputTxt);





// ADDFootballer funtion
footballer* addFootballer(string name , string tname){
	
	footballer *temp = new footballer();
	temp->setName(name);
	temp->setTeamName(tname);
	
	return temp;
	
}


//As�l futbolcu ve gol ekleme k�sm�  , e�er futbolcu varsa sadece gol ekleme k�sm�
void find_Footballer_and_add_Match(string fname  , string tname , string away_team , int minute_of_goal , int match_id){

	footballer *q = NULL;
	footballer *p = footballer_head;


	while(p!=NULL  && p->getName().compare(fname) < 0 ){
		
		
		q=p;
		p=p->next_footballer;
		
	}
	if(p!=NULL && p->getName().compare(fname) == 0){   // Ayn� isimden olma durumu
		
		p->addGoal(away_team, minute_of_goal, match_id);
	}
	else if(q==NULL){      // En ba�a ekleme durumu
		
		footballer_head = addFootballer( fname, tname);
		footballer_head->addGoal(away_team, minute_of_goal , match_id);
		footballer_head->next_footballer = p;		
	}
	else{  // En sona ekleme durumu ve araya ekleme durumu
		
		q->next_footballer = addFootballer(fname,tname);
		q->next_footballer->addGoal(away_team, minute_of_goal , match_id);
		q->next_footballer->next_footballer = p;
		
	}
	


}

//Open the input.txt and create linkedlist
void createLinkedList(char *textName){
	
	int max=300, i;    char buf[max];   char *ptr;

	int minute_of_goal , match_id;
	string footballer_name , team_name , away_team;

	
	//DOSYA OKUMA KISMI
	ifstream input (textName);    // textNameye �evirilecek...

	if(	input.is_open() ){

		while( ! input.eof()){
			
			input.getline(buf,max);
			buf[ strcspn(buf,"\r\n") ] = 0;
			
			if(strlen(buf) > 0){

				i=0;
				ptr = strtok(buf , ",");
	
				while(ptr != NULL){
					
					if(i==0)  footballer_name = ptr;
					if(i==1)  team_name       = ptr;
					if(i==2)  away_team       = ptr;
					if(i==3)  minute_of_goal  = atoi(ptr);
					if(i==4)  match_id        = atoi(ptr);
					
					i++;
					ptr = strtok(NULL , ",");
				}
				find_Footballer_and_add_Match(footballer_name ,team_name , away_team , minute_of_goal , match_id);				
			}
		}
		input.close();		
	}		
}


footballer* findFootballer(char *ptr){   // find footballer in linkedlist
	
	footballer *q= footballer_head;
	
	for(;q;q=q->next_footballer){
		
		if(q->getName().compare(ptr) == 0){
			
			return q;
		}
	}
	
	return NULL;
	
}


void worksOperands(char *textName , char *outputTxt){          // the function do operands
	
	int max=200;          char buf[max];       char *ptr;       int counter = 1 ,secondCounter  , firstHalfScore=0 , secondHalfScore=0  ;  
	
	
	ifstream input(textName);
	


	
	if( input.is_open() ){      // The txt is open?
		
		ofstream output;
		output.open(outputTxt);
		
		
		while(counter!=6){
			
			if(counter==1){             // THE MOST HALF SCORED
				
				footballer *q = footballer_head;
				while(q){
					goal *p = q->goal_head;
					while(p){
						if( p->getMinuteOfGoal() <= 45 ) firstHalfScore++;
						else                            secondHalfScore++;
						p= p->next_goal;
					}
					q= q->next_footballer;
				}
				
				output << "1)THE MOST SCORED HALF" <<endl;
				if ( firstHalfScore > secondHalfScore )                      output << "0"<<endl;
				else  if ( secondHalfScore > firstHalfScore)                 output << "1"<<endl;
				else                   										 output << "-1"<<endl;
			}
			
			
			
			
			else if(counter==2){      //  MOST GOAL SCORER
				
				output << "2)GOAL SCORER" << endl;
				
				footballer *m = footballer_head;
				footballer *l = m;
				m = m->next_footballer;
				
				while(m){
					
					if(m->getGoalNumbers() > l->getGoalNumbers() ){
						
						l = m;
					}
					m = m->next_footballer ;
				}
				
				m = footballer_head;
				
				while(m){
					if(m->getGoalNumbers() == l->getGoalNumbers()){
						
						output << m->getName() << endl;
					}
					m = m->next_footballer;
				}
				
				
			}
			
			else if(counter==3){        // HATRICK

				
				footballer *q = footballer_head;
				
				output <<"3)THE NAMES OF FOOTBALLERS WHO SCORED HAT-TRICK" << endl;
				
				while(q){
					
					int sayac = 0, temp;	
					goal *p = q->goal_head;
					
					while(p){
						
						if(p== q->goal_head){
							
							temp = p->getMatchID();
							sayac++;
						}  
						else if( p->getMatchID() == temp ){
							
							sayac++;
							
							if(sayac >= 3){
								
								output << q->getName() << endl ;
								
								break;
							}
						}
						else if ( p->getMatchID() != temp){

							sayac == 0;
							temp = p->getMatchID();
						}
						
						p=p->next_goal;
					}
					
					q= q->next_footballer;
				}



			}
			else if(counter==4){        // LIST OF TEAMS
				
				output<< "4)LIST OF TEAMS" << endl;
				
				footballer *q = footballer_head;
	
				while(q){
					

						
					team *r = NULL;                   // Team linked listi olu�turuluyor.
					team *k = team_head;
						
					while(k!=NULL && k->teamName.compare(q->getTeamName()) != 0){
							
						r=k;
						k = k->next_Team;
					}
					if(k!=NULL && k->teamName.compare(q->getTeamName()) == 0){
							
							//Ayn� tak�m var
					}
					else if(r==NULL){
							
						team_head = new team(q->getTeamName());
						team_head->next_Team = r ;
					}
					else{
								
						r->next_Team = new team(q->getTeamName());
						r->next_Team->next_Team = k;	
					}

							
					q= q->next_footballer;
				}
				
				team *k = team_head;
				
				while(k){
					
					output << k->teamName << endl;
					
					k= k->next_Team;
				}
			}
			
			else if(counter==5){         // LIST OF FOOTBALLERS
				
				footballer *q= footballer_head;
				output<< "5)LIST OF FOOTBALLERS" << endl;
				while(q){
					
					output << q->getName() <<endl;
					q=q->next_footballer;
				}
			}
			counter++;
		}
		
		
		
		
		
		
		while(! input.eof() ){
		
			input.getline(buf,max);

			buf[ strcspn(buf,"\r\n") ] = 0;

			if(strlen(buf) >0){

				if(counter==6)       output << "6)MATCHES OF GIVEN FOOTBALLER" << endl ;
				else if(counter==7)  output << "7)ASCENDING ORDER ACCORDING TO MATCH ID" <<endl;
				else if(counter==8)  output << "8)DESCENDING ORDER ACCORDING TO MATCH ID" <<endl;
				
				ptr = strtok(buf , ",");
					
				while(ptr!=NULL){
					
					if(counter==6){         // GOALS
						
						footballer *q = findFootballer(ptr);
						goal *p = q->goal_head;

						for( ;p;p=p->next_goal){
				
							if (p == q->goal_head ) output << "Matches of " << q->getName() << endl ;
							output << "Footballer Name: " << q->getName() << ",Away Team: " << p->getAwayTeam() << ",Min of Goal: " << p->getMinuteOfGoal() << ",Match ID: " << p->getMatchID() << endl;
						}
						
						
					}
					else if(counter==7){         // ASCENDING ORDER
						
						footballer *q = findFootballer(ptr);
						goal *p = q->goal_head;
						
						for( ;p;p=p->next_goal){
							
							if(p == q->goal_head){
								
								output << "footballer Name: " <<q->getName() << ",Match ID: " << p->getMatchID() <<endl;
								secondCounter = p->getMatchID();
							}
							else if( p->getMatchID() != secondCounter){
								
								output << "footballer Name: " <<q->getName() << ",Match ID: " << p->getMatchID() <<endl;
								secondCounter = p->getMatchID();
								
							} 
						}
						
					}
					else if(counter==8){       // DESCENDING ORDER
						
						footballer *q = findFootballer(ptr);
						q->reverse_Goals();
						goal *p = q->goal_head;
						
						for( ;p;p=p->next_goal){
							
							if(p == q->goal_head){
								
								output << "footballer Name: " <<q->getName() << ",Match ID: " << p->getMatchID() <<endl;
								secondCounter = p->getMatchID();
							}
							else if( p->getMatchID() != secondCounter){
								
								
								output << "footballer Name: " <<q->getName() << ",Match ID: " << p->getMatchID() <<endl;
								secondCounter = p->getMatchID();
								
							} 
						}						
					}


					ptr = strtok(NULL , ",");
				}
				
				counter++;
				
			}
		}
		input.close();
		output.close();
	}
	
	
}


#endif
