#include <iostream> 

#include "Class.h"
#include "Functions.h"
using namespace std;



int main(int argc , char **argv){
	

	if ( argc == 4){
		
		createLinkedList(argv[1]);
		worksOperands(argv[2], argv[3]);		
		
	}

	
	return 0;
}




