#ifndef DENEME_H
#define DENEME_H

#include <iostream>
#include <fstream>
using namespace std;


class team{
	
	public:
		string teamName; 
		team *next_Team;
		
		team(string tName){
			
			teamName = tName;
		}
};







//CLASSES
class goal{                 // GOAL CLASS 
	
	private:
	
		string away_team;
		int match_id;
		int minute_of_goal;
	
    public:
	
		goal *previous_goal;
		goal *next_goal;

		
		goal(){
			
			previous_goal = NULL;
			next_goal     = NULL;	
			
		}
		void setAwayTeam(string away_team){
			
			this->away_team = away_team;
		}
		void setMatchID(int match_id){
			
			this->match_id = match_id;
		}
		void setMinuteOfGoal(int minute_of_goal){
			
			this->minute_of_goal = minute_of_goal;
		}
		string getAwayTeam(){
			
			return this->away_team;
		}
		int getMatchID(){
			
			return this->match_id;
		}
		int getMinuteOfGoal(){
			
			return this->minute_of_goal;
		}
	
};












class footballer{          // FOOTBALLER CLASS 
	
	private:
	
		string footballer_name;
		string footballers_team_name;
		int goalNumber;	
	
	public:
		

		footballer *next_footballer;
		
		goal *goal_head;
	
		footballer(){
			
						
			next_footballer = NULL;
					
			goal_head = NULL;
			goalNumber = 0;
		}
		
		
		
		
		
		
		void  addGoal(string away_team , int minute_of_goal , int match_id){
			
			goal *q= NULL;
			goal *p= goal_head;
			
			goal *temp_goal = new goal();
			temp_goal->setAwayTeam(away_team);
			temp_goal->setMinuteOfGoal(minute_of_goal);
			temp_goal->setMatchID(match_id);
			
			while(p!=NULL && p->getMatchID() < match_id  ) {       // Match id ye g�re sort k�sm�
				
				q=p;
				p= p->next_goal;
			}
			if(p!= NULL && p->getMatchID() == match_id ){
				
				while(p!= NULL && p->getMatchID() == match_id  && p->getMinuteOfGoal() < minute_of_goal ){   // MinuteofGoal e g�re sort k�sm�
					
					q=p;
					p= p->next_goal;
				}
				if(p!=NULL && p->getMatchID() == match_id && p->getMinuteOfGoal() == minute_of_goal){
					
					temp_goal->next_goal = p->next_goal;
					p->next_goal = temp_goal;
				}
				else if(q== NULL){
					
					goal_head = temp_goal;
					goal_head->next_goal = p;
				}
				else{
					
					q->next_goal = temp_goal;
					temp_goal->next_goal = p;
				}
				
				
			}
			else if(q==NULL){        // En ba�a ekleme durumu
				
				goal_head = temp_goal;
				goal_head->next_goal = p;
			}	
			else{               // En sona ve araya ekleme durumu
				
				q->next_goal = temp_goal;
				q->next_goal->next_goal = p;
				
			}
			goalNumber++;
		}
		
		void reverse_Goals(){
			
			goal *r = NULL;
			goal *q = NULL;
			goal *p = goal_head;
			
			while(p!=NULL){
				
				r=q;
				q=p;
				p=p->next_goal;
				q->next_goal = r;
			}
			goal_head = q;
		}
		
		
		
		
		
		
		
		void  setName(string name){
			
			this->footballer_name = name;
		}
		void  setTeamName(string team_name){
			
			this->footballers_team_name = team_name;
		}
		string getName(){
			
			return this->footballer_name;
		}
		string getTeamName(){
			
			return this->footballers_team_name;
		}
		int getGoalNumbers(){
			
			return this->goalNumber;
		}		
		
};


#endif
