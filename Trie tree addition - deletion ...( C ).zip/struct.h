
struct n{
	
	struct n* alphabet[26];
	int password;
	int childNumber;	
	
};

typedef struct n node;




